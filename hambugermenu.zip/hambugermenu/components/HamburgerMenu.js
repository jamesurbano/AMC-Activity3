import React, {useState} from 'react';

import {SafeAreaView, Animated,View, TouchableOpacity, Text,StyleSheet,ScrollView } from 'react-native';

import {Menu, X} from 'lucide-react-native';


const HamburgerMenu = () => {


  const [menuOpen, setMenuOpen] = useState(false);

  const slideAnim = useState(new Animated.Value(-300))[0];


  const toggleMenu = () => {

    const toValue = menuOpen ? -300 : 0;


    Animated.timing(slideAnim, {

      toValue,

      duration: 300,

      useNativeDriver: true,

    }).start()



  setMenuOpen(!menuOpen);

  };



  const menuItems = [

    {id: 1, title: 'Home',screen: 'HomeScreen'},

    {id: 1, title: 'Profile',screen: 'ProfileScreen'},

  ];


  return (

    <SafeAreaView style={styles.container}>

     <View style={styles.header}>

       <TouchableOpacity onPress={toggleMenu} style={styles.menuButton}>

       {menuOpen ? <X size={24} color="#000" /> : <Menu size ={24}

       color="#000"/>}

       </TouchableOpacity>

       <Text style={styles.headerTitle}> My App </Text>

     </View>


    {menuOpen && (

      <TouchableOpacity

      style={styles.overlay}

      activeOpacity={1}

      onPress={toggleMenu} />

    )}


    <Animated.View

    style={[styles.menu,

    {transform: [{ translateX: slideAnim}] },

    ]}

    >

    <ScrollView>

     <View>

       <Text>Menu</Text>

     </View>

     

     <View>

       {menuItems.map((item) => (

           <TouchableOpacity>

       key={item.id}

       onPress={() => {

         toggleMenu();

       }}

       >

       <Text>{item.title}</Text>

       </TouchableOpacity>

       ))}


     </View>

    </ScrollView>


    </Animated.View>


    </SafeAreaView>

  );


};


const styles = StyleSheet.create({

  container: {

    flex:1,

    backgroundColor: '#f5f5f5'

  },


  header: {

    height: 60,

    backgroundColor: '#fff',

    flexDirection: 'row',

    alignItems:'center',

    paddingHorizontal: 15,

    borderBottomWidth: 1,

    borderBottomColor: '#e0e0e0',

  },


  menuButton: {

    padding: 5,


  },


  headerTitle: {

    fontSize: 18,

    fontWeight: 'bold',

    marginLeft: 20,

  },


  overlay: {

    position:'absolute',

    top: 60,

    left:0,

    right:0,

    bottom:0,

    backgroundColor: 'rgba (0,0,0,0,5)',

    zindex: 1,


  },


  menu: {

    position:'absolute',

    top: 60,

    left:0,

    width:300,

    right:0,

    bottom:0,

    backgroundColor: 'rgba (0,0,0,0,5)',

    zindex: 1,

    shadowColor:'#000',

    shadowoffset: {width: 2, height: 0},

    shdowOpacity: 0.2,

    shadowRadius: 5,

    elevation:5,

    

  },



});


export default HamburgerMenu;